import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { StoryImage } from '@/components/story-image'
import { type Story, getCategoryName, formatDate } from '@/lib/news-data'

function CategoryTag({ category }: { category: Story['category'] }) {
  return (
    <span className="inline-block rounded-full bg-primary px-3 py-1 text-[0.68rem] font-bold uppercase tracking-[0.08em] text-primary-foreground shadow-sm">
      {getCategoryName(category)}
    </span>
  )
}

export function StoryCard({
  story,
  variant = 'default',
}: {
  story: Story
  variant?: 'default' | 'compact' | 'feature'
}) {
  const href = `/story/${story.slug ?? story.id}`

  if (variant === 'compact') {
    return (
      <article className="group flex gap-4 border-b border-border pb-4 last:border-b-0">
        <Link
          href={href}
          className="relative aspect-square w-24 shrink-0 overflow-hidden rounded-xl sm:w-28"
        >
          <StoryImage
            src={story.image}
            alt={story.title}
            sizes="112px"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            category={story.category}
          />
        </Link>

        <div className="min-w-0">
          <Link href={`/category/${story.category}`}>
            <CategoryTag category={story.category} />
          </Link>
          <h3 className="mt-2 line-clamp-3 font-serif text-base font-bold leading-snug">
            <Link href={href} className="transition-colors hover:text-primary">
              {story.title}
            </Link>
          </h3>
          <p className="mt-2 text-[0.7rem] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
            {formatDate(story.date)}
          </p>
        </div>
      </article>
    )
  }

  const feature = variant === 'feature'

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border/80 bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl">
      <div
        className={`relative w-full overflow-hidden ${
          feature ? 'aspect-[16/9]' : 'aspect-[3/2]'
        }`}
      >
        <Link href={href} className="absolute inset-0">
          <StoryImage
            src={story.image}
            alt={story.title}
            sizes={
              feature
                ? '(max-width: 768px) 100vw, 66vw'
                : '(max-width: 768px) 100vw, 33vw'
            }
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            category={story.category}
          />
        </Link>

        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/45 to-transparent" />

        <Link
          href={`/category/${story.category}`}
          className="absolute left-4 top-4"
        >
          <CategoryTag category={story.category} />
        </Link>
      </div>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <p className="text-[0.7rem] font-bold uppercase tracking-[0.12em] text-muted-foreground">
          {formatDate(story.date)}
          {story.author ? ` · By ${story.author}` : ''}
        </p>

        <h3
          className={`mt-3 line-clamp-3 font-serif font-bold leading-[1.12] text-balance ${
            feature ? 'text-2xl sm:text-4xl' : 'text-xl sm:text-[1.35rem]'
          }`}
        >
          <Link href={href} className="transition-colors hover:text-primary">
            {story.title}
          </Link>
        </h3>

        {story.summary && (
          <p
            className={`mt-3 leading-relaxed text-muted-foreground ${
              feature ? 'line-clamp-3 text-base' : 'line-clamp-3 text-sm'
            }`}
          >
            {story.summary}
          </p>
        )}

        {feature && story.communityAngle && (
          <div className="mt-5 rounded-xl border-l-4 border-accent bg-secondary p-4">
            <p className="text-xs font-bold uppercase tracking-[0.1em] text-accent">
              Community Angle
            </p>
            <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-foreground/80">
              {story.communityAngle}
            </p>
          </div>
        )}

        <div className="mt-auto flex items-center justify-between gap-3 border-t border-border pt-4">
          <span className="min-w-0 truncate text-xs text-muted-foreground">
            Source: <strong className="font-semibold text-foreground/75">{story.sourceName}</strong>
          </span>

          <a
            href={story.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-primary px-3 py-2 text-xs font-bold text-primary-foreground transition-opacity hover:opacity-90"
          >
            Read original
            <ArrowUpRight className="size-3.5" />
          </a>
        </div>
      </div>
    </article>
  )
}
