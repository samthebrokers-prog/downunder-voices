(function () {
  // Replace placeholders later with Google AdSense or direct sponsor code.
  // Until approval, this keeps visible ad spaces in the correct positions.
  const slots = document.querySelectorAll('[data-ad-slot]');
  slots.forEach(slot => {
    const label = slot.getAttribute('data-ad-slot') || 'Advertisement';
    if (!slot.innerHTML.trim()) {
      slot.innerHTML = `<div><strong>Advertisement</strong>${label} ad space</div>`;
    }
  });
})();
