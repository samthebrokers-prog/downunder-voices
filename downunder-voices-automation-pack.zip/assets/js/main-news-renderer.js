(function () {
  const posts = window.DV_POSTS || window.posts || [];

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function formatDate(value) {
    if (!value) return '';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  function filterPosts(category) {
    if (!category || category === 'All') return posts;
    return posts.filter(p => String(p.category || '').toLowerCase() === String(category).toLowerCase());
  }

  function postCard(post) {
    const image = post.image ? `style="background-image:linear-gradient(180deg,rgba(3,29,62,.15),rgba(3,29,62,.55)),url('${escapeHtml(post.image)}');background-size:cover;background-position:center"` : '';
    return `
      <article class="image-card news-card">
        <a href="${escapeHtml(post.url)}" target="_blank" rel="noopener">
          <div class="card-img visual city" ${image}></div>
          <div class="card-body">
            <div class="cat">${escapeHtml(post.category)}</div>
            <h3>${escapeHtml(post.title)}</h3>
            <p class="news-summary">${escapeHtml(post.summary || '')}</p>
            <div class="date">◷ ${escapeHtml(formatDate(post.date))} · ${escapeHtml(post.source || '')}</div>
          </div>
        </a>
      </article>`;
  }

  function feedItem(post) {
    return `
      <a class="feed-item" href="${escapeHtml(post.url)}" target="_blank" rel="noopener">
        <div class="feed-time">${escapeHtml(post.category || 'News')}</div>
        <div class="feed-title">${escapeHtml(post.title)}<br><small>${escapeHtml(post.source || '')}</small></div>
        <div>›</div>
      </a>`;
  }

  document.querySelectorAll('[data-posts]').forEach(el => {
    const category = el.getAttribute('data-category') || 'All';
    const limit = Number(el.getAttribute('data-limit') || 3);
    const items = filterPosts(category).slice(0, limit);
    el.innerHTML = items.length ? items.map(postCard).join('') : '<p>No stories loaded yet.</p>';
  });

  document.querySelectorAll('[data-feed]').forEach(el => {
    const limit = Number(el.getAttribute('data-limit') || 6);
    el.innerHTML = posts.slice(0, limit).map(feedItem).join('');
  });
})();
