// Initial placeholder. This file will be replaced by scripts/fetch-news.mjs
window.DV_NEWS_DATA = {
  generatedAt: new Date().toISOString(),
  site: 'Downunder Voices',
  rule: 'Short summaries and source links only. Do not copy full publisher articles.',
  articles: [
    {
      id: 'sample-001',
      title: 'Downunder Voices automation ready',
      category: 'Community Voices',
      summary: 'The website is ready to load curated news from approved sources using an automated daily update file.',
      source: 'Downunder Voices',
      url: 'curated-news.html',
      originalUrl: 'curated-news.html',
      date: new Date().toISOString(),
      image: '',
      communityAngle: 'Public-interest update for Downunder Voices readers.',
      publishNote: 'Sample item. Replace after first automated import.'
    }
  ]
};
window.DV_POSTS = window.DV_NEWS_DATA.articles;
window.posts = window.DV_POSTS;
