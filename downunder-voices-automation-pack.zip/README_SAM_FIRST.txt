DOWNUNDER VOICES - AUTOMATION PACK

Machan, this is the automation logic for the existing static site. It is NOT WordPress.

WHAT THIS DOES
1. Reads approved RSS sources from: assets/data/sources.json
2. Fetches latest items every morning.
3. Removes duplicates using article URL/GUID/hash.
4. Saves short summaries only, not full copied articles.
5. Writes:
   - assets/data/news.json
   - assets/js/posts.js
   - assets/data/import-log.json
6. The website then shows stories from assets/js/posts.js.
7. Includes ad-space CSS/JS and HTML snippets.

IMPORTANT
- If the site is only uploaded manually to Netlify, automation will not run by itself.
- Best setup: upload the website to GitHub and connect GitHub to Netlify or Vercel.
- GitHub Actions will run every morning and commit updated news files.
- Netlify/Vercel will then redeploy automatically from GitHub.

HOW TO INSTALL
1. Copy these folders/files into the website root:
   package.json
   scripts/fetch-news.mjs
   assets/data/sources.json
   assets/js/main-news-renderer.js
   assets/css/ad-slots.css
   assets/js/ads.js
   .github/workflows/update-news.yml

2. Check your index.html already has:
   <script src="assets/js/posts.js"></script>
   <script src="assets/js/main.js"></script>

3. If the existing main.js does not render the news properly, replace/add:
   <script src="assets/js/posts.js"></script>
   <script src="assets/js/main-news-renderer.js"></script>

4. Add ad spaces using:
   snippets/ad-space-html.txt

5. Test locally or in GitHub Actions:
   npm install
   npm run fetch-news

6. Check:
   assets/js/posts.js
   assets/data/news.json
   assets/data/import-log.json

SOURCE RULE
Use only approved RSS feeds/sources. Do not copy full articles. Show headline, short summary, source name and original link.

AD SPACE RULE
Ad spaces are placeholders first. After Google AdSense or sponsor approval, replace placeholder blocks with ad code.
