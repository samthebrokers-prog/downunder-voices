import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import Parser from 'rss-parser';

const ROOT = process.cwd();
const SOURCES_FILE = path.join(ROOT, 'assets/data/sources.json');
const JSON_OUTPUT = path.join(ROOT, 'assets/data/news.json');
const JS_OUTPUT = path.join(ROOT, 'assets/js/posts.js');
const LOG_OUTPUT = path.join(ROOT, 'assets/data/import-log.json');

const parser = new Parser({
  timeout: 15000,
  headers: {
    'User-Agent': 'DownunderVoicesBot/1.0 (+https://downundervoices.com)'
  },
  customFields: {
    item: [
      ['media:content', 'mediaContent', { keepArray: true }],
      ['media:thumbnail', 'mediaThumbnail', { keepArray: true }],
      ['content:encoded', 'contentEncoded'],
      ['dc:creator', 'creator']
    ]
  }
});

function stripHtml(input = '') {
  return String(input)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function truncate(text, max = 240) {
  const clean = stripHtml(text);
  if (clean.length <= max) return clean;
  return clean.slice(0, max - 1).replace(/\s+\S*$/, '') + '…';
}

function itemImage(item) {
  if (item.enclosure?.url && /^https?:/i.test(item.enclosure.url)) return item.enclosure.url;

  const mediaContent = Array.isArray(item.mediaContent) ? item.mediaContent : [];
  for (const media of mediaContent) {
    if (media?.$?.url && /^https?:/i.test(media.$.url)) return media.$.url;
  }

  const mediaThumb = Array.isArray(item.mediaThumbnail) ? item.mediaThumbnail : [];
  for (const media of mediaThumb) {
    if (media?.$?.url && /^https?:/i.test(media.$.url)) return media.$.url;
  }

  const html = item.contentEncoded || item.content || '';
  const match = String(html).match(/<img[^>]+src=["']([^"']+)["']/i);
  if (match?.[1] && /^https?:/i.test(match[1])) return match[1];
  return '';
}

function cleanUrl(url = '') {
  try {
    const u = new URL(url);
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'].forEach(p => u.searchParams.delete(p));
    return u.toString();
  } catch {
    return url;
  }
}

function makeId(sourceName, item) {
  const raw = item.guid || item.id || item.link || `${sourceName}:${item.title}`;
  return crypto.createHash('sha256').update(String(raw)).digest('hex').slice(0, 16);
}

function communityAngleFor(category) {
  const c = String(category || '').toLowerCase();
  if (c.includes('sport')) return 'Sport and community interest for Australian, New Zealand and Pacific readers.';
  if (c.includes('business')) return 'Small business and household cost-of-living relevance.';
  if (c.includes('pacific') || c.includes('zealand')) return 'Relevant to Kiwi, Pacific and trans-Tasman communities.';
  if (c.includes('australia')) return 'Relevant to Australian residents, migrants and local communities.';
  return 'Public-interest update for Downunder Voices readers.';
}

async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(file, 'utf8'));
  } catch {
    return fallback;
  }
}

async function main() {
  const startedAt = new Date().toISOString();
  const sources = (await readJson(SOURCES_FILE, [])).filter(s => s.active !== false && s.feedUrl);
  const existing = await readJson(JSON_OUTPUT, { generatedAt: null, articles: [] });
  const existingArticles = Array.isArray(existing.articles) ? existing.articles : [];
  const seen = new Set(existingArticles.map(a => a.id || a.url).filter(Boolean));
  const imported = [];
  const errors = [];
  const skippedDuplicates = [];

  for (const source of sources) {
    try {
      const feed = await parser.parseURL(source.feedUrl);
      const items = (feed.items || []).slice(0, Number(source.maxItems || 5));

      for (const item of items) {
        const url = cleanUrl(item.link || item.guid || '');
        const id = makeId(source.name, item);
        if (!url || seen.has(id) || seen.has(url)) {
          skippedDuplicates.push({ source: source.name, title: item.title || '', url });
          continue;
        }

        seen.add(id);
        seen.add(url);

        const title = stripHtml(item.title || '').trim();
        if (!title) continue;

        const summarySource = item.contentSnippet || item.summary || item.content || item.contentEncoded || '';
        imported.push({
          id,
          title,
          category: source.category || 'News',
          summary: truncate(summarySource, 240),
          source: source.name,
          url,
          originalUrl: url,
          date: item.isoDate || item.pubDate || startedAt,
          image: itemImage(item),
          communityAngle: communityAngleFor(source.category),
          publishNote: 'Imported from approved RSS source. Short summary only. Read full story at original publisher.'
        });
      }
    } catch (err) {
      errors.push({ source: source.name, feedUrl: source.feedUrl, error: err.message });
    }
  }

  const merged = [...imported, ...existingArticles]
    .filter((article, index, array) => array.findIndex(a => (a.id && a.id === article.id) || (a.url && a.url === article.url)) === index)
    .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0))
    .slice(0, 120);

  const output = {
    generatedAt: new Date().toISOString(),
    site: 'Downunder Voices',
    rule: 'Short summaries and source links only. Do not copy full publisher articles.',
    articles: merged
  };

  await fs.mkdir(path.dirname(JSON_OUTPUT), { recursive: true });
  await fs.mkdir(path.dirname(JS_OUTPUT), { recursive: true });

  await fs.writeFile(JSON_OUTPUT, JSON.stringify(output, null, 2));

  const js = `// Auto-generated by scripts/fetch-news.mjs. Do not edit this file manually.\n` +
    `// Edit assets/data/sources.json or run: npm run fetch-news\n` +
    `window.DV_NEWS_DATA = ${JSON.stringify(output, null, 2)};\n` +
    `window.DV_POSTS = window.DV_NEWS_DATA.articles;\n` +
    `window.posts = window.DV_POSTS;\n`;
  await fs.writeFile(JS_OUTPUT, js);

  const log = {
    startedAt,
    finishedAt: new Date().toISOString(),
    sourcesChecked: sources.length,
    importedCount: imported.length,
    duplicateCount: skippedDuplicates.length,
    errors,
    imported: imported.map(a => ({ title: a.title, source: a.source, category: a.category, url: a.url }))
  };
  await fs.writeFile(LOG_OUTPUT, JSON.stringify(log, null, 2));

  console.log(`Imported ${imported.length} new article(s). Duplicates skipped: ${skippedDuplicates.length}. Errors: ${errors.length}.`);
  if (errors.length) {
    console.log(JSON.stringify(errors, null, 2));
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
