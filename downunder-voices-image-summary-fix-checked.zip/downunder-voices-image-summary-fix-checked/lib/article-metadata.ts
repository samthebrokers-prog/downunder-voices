function decodeEntities(value: string): string {
  return value
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
}

function cleanText(value: string): string {
  return decodeEntities(value)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function metaContent(html: string, names: string[]): string {
  for (const name of names) {
    const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    const patterns = [
      new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]+content=["']([^"']+)["'][^>]*>`, 'i'),
      new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${escaped}["'][^>]*>`, 'i'),
    ]

    for (const pattern of patterns) {
      const match = html.match(pattern)
      if (match?.[1]) return decodeEntities(match[1]).trim()
    }
  }

  return ''
}

function absoluteUrl(value: string, pageUrl: string): string | undefined {
  if (!value) return undefined

  try {
    const url = new URL(value, pageUrl)
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return undefined
    return url.toString()
  } catch {
    return undefined
  }
}

function firstTwoSentences(value: string, maxLength = 460): string {
  const text = cleanText(value)
  if (!text) return ''

  const sentences = text.match(/[^.!?]+[.!?]+(?:["'”’)]*)|[^.!?]+$/g) ?? [text]
  let result = ''

  for (const sentence of sentences.slice(0, 2)) {
    const candidate = `${result}${result ? ' ' : ''}${sentence.trim()}`
    if (candidate.length > maxLength) break
    result = candidate
  }

  if (!result) {
    const shortened = text.slice(0, maxLength).trim()
    const lastSpace = shortened.lastIndexOf(' ')
    result = `${shortened.slice(0, lastSpace > 250 ? lastSpace : shortened.length).replace(/[,:;\-\s]+$/, '')}…`
  }

  return result.trim()
}

function usefulSummary(primary: string, secondary: string): string {
  const first = cleanText(primary)
  const second = cleanText(secondary)

  if (!first) return firstTwoSentences(second)
  if (!second) return firstTwoSentences(first)

  const firstLower = first.toLowerCase()
  const secondLower = second.toLowerCase()

  if (
    firstLower === secondLower ||
    firstLower.includes(secondLower) ||
    secondLower.includes(firstLower)
  ) {
    return firstTwoSentences(first.length >= second.length ? first : second)
  }

  return firstTwoSentences(`${first}${/[.!?]$/.test(first) ? '' : '.'} ${second}`)
}

export async function enrichArticle(
  pageUrl: string,
  rssDescription: string,
  rssImage?: string,
): Promise<{ summary: string; imageUrl?: string }> {
  let summary = firstTwoSentences(rssDescription)
  let imageUrl = absoluteUrl(rssImage || '', pageUrl)

  try {
    const response = await fetch(pageUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; DownunderVoicesBot/1.0; +https://downundervoices.com)',
        Accept: 'text/html,application/xhtml+xml',
      },
      signal: AbortSignal.timeout(8000),
      cache: 'no-store',
      redirect: 'follow',
    })

    if (!response.ok) return { summary, imageUrl }

    const contentType = response.headers.get('content-type') || ''
    if (!contentType.includes('text/html')) return { summary, imageUrl }

    const html = await response.text()
    const pageDescription = metaContent(html, [
      'og:description',
      'twitter:description',
      'description',
    ])
    const pageImage = metaContent(html, [
      'og:image:secure_url',
      'og:image',
      'twitter:image',
      'twitter:image:src',
    ])

    summary = usefulSummary(rssDescription, pageDescription)
    imageUrl = imageUrl || absoluteUrl(pageImage, response.url || pageUrl)
  } catch {
    // Keep the RSS text and image when a publisher blocks page access.
  }

  return { summary, imageUrl }
}
