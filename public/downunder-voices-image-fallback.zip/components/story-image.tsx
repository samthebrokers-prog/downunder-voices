'use client'

import { useMemo, useState } from 'react'
import { fallbackImageForCategory } from '@/lib/fallback-images'

type StoryImageProps = {
  src?: string | null
  alt: string
  category?: string | null
  className?: string
  sizes?: string
  priority?: boolean
}

/**
 * Shows the publisher image when available.
 * Automatically switches to a Downunder Voices category image when the
 * original image is missing, blocked, expired, hotlink-protected or broken.
 *
 * Uses a normal <img> element so external publishers do not need to be added
 * individually to next.config image domains.
 */
export default function StoryImage({
  src,
  alt,
  category,
  className,
  sizes = '100vw',
  priority = false,
}: StoryImageProps) {
  const fallback = useMemo(
    () => fallbackImageForCategory(category),
    [category],
  )

  const [imageSrc, setImageSrc] = useState(
    src?.trim() || fallback,
  )

  return (
    <img
      src={imageSrc}
      alt={alt}
      className={className}
      sizes={sizes}
      loading={priority ? 'eager' : 'lazy'}
      fetchPriority={priority ? 'high' : 'auto'}
      onError={() => {
        if (imageSrc !== fallback) {
          setImageSrc(fallback)
        }
      }}
    />
  )
}
