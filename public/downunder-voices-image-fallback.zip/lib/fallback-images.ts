const FALLBACK_IMAGES: Record<string, string> = {
  politics: '/fallback/politics.svg',
  business: '/fallback/business.svg',
  australia: '/fallback/australia.svg',
  'nz-pacific': '/fallback/nz-pacific.svg',
  community: '/fallback/community.svg',
  sports: '/fallback/sports.svg',
}

export function fallbackImageForCategory(
  category?: string | null,
): string {
  if (!category) return '/fallback/default.svg'
  return FALLBACK_IMAGES[category] || '/fallback/default.svg'
}
