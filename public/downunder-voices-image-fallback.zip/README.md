# Downunder Voices automatic image fallback

This package prevents grey or broken article images.

## Add these files to the same paths in the repository

- `components/story-image.tsx`
- `lib/fallback-images.ts`
- everything inside `public/fallback/`

## Replace the existing article/card image

Find the component that displays a story image. Replace its current `<Image ... />`
or `<img ... />` block with:

```tsx
import StoryImage from '@/components/story-image'

<StoryImage
  src={story.image_url}
  alt={story.title}
  category={story.category}
  className="h-full w-full object-cover"
/>
```

Keep the surrounding container and layout classes already used by the site.

## Optional importer improvement

In `lib/importer.ts`, import:

```ts
import { fallbackImageForCategory } from '@/lib/fallback-images'
```

Then replace:

```ts
image_url: item.imageUrl || null,
```

with:

```ts
image_url: item.imageUrl || fallbackImageForCategory(category),
```

The frontend component is the essential part because it also handles images that become
blocked or broken after import.
