import { NextResponse } from 'next/server'
import { runNewsImport } from '@/lib/importer'

export const maxDuration = 300
export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  const auth = request.headers.get('authorization')
  const userAgent = request.headers.get('user-agent') || ''
  const secret = process.env.CRON_SECRET

  const authorised = secret
    ? auth === `Bearer ${secret}`
    : userAgent.toLowerCase().includes('vercel-cron')

  if (!authorised) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
  }

  try {
    const results = await runNewsImport()
    const imported = results.reduce((total, result) => total + result.imported, 0)
    const errors = results.filter((result) => result.error)
    return NextResponse.json({ ok: errors.length === 0, imported, checkedAt: new Date().toISOString(), results }, { status: errors.length ? 207 : 200 })
  } catch (error) {
    console.error('Scheduled news import failed:', error)
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Import failed' }, { status: 500 })
  }
}
