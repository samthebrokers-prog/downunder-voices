import type { CategorySlug } from '@/lib/news-data'

type TopicRule = { image: string; pattern: RegExp }

const topicRules: TopicRule[] = [
  { image: '/topic-images/prison.svg', pattern: /prison|inmate|correction|jail|gaol|contraband/ },
  { image: '/topic-images/courts.svg', pattern: /court|judge|judicial|lawsuit|sentence|trial|appeal/ },
  { image: '/topic-images/police.svg', pattern: /police|officer|detective|arrest|investigation/ },
  { image: '/topic-images/crime.svg', pattern: /crime|murder|assault|theft|robbery|fraud|victim/ },
  { image: '/topic-images/justice.svg', pattern: /justice|rights|law reform|accountability/ },
  { image: '/topic-images/parliament-nz.svg', pattern: /beehive|new zealand parliament|nz parliament|wellington government/ },
  { image: '/topic-images/parliament-au.svg', pattern: /canberra|australian parliament|federal parliament/ },
  { image: '/topic-images/election.svg', pattern: /election|campaign|polling|ballot|vote|electorate/ },
  { image: '/topic-images/political-leaders.svg', pattern: /prime minister|premier|opposition leader|political leader/ },
  { image: '/topic-images/government.svg', pattern: /government|minister|cabinet|parliament|policy|coalition/ },
  { image: '/topic-images/mental-health.svg', pattern: /mental health|depression|anxiety|wellbeing|suicide prevention/ },
  { image: '/topic-images/ambulance.svg', pattern: /ambulance|paramedic|emergency service/ },
  { image: '/topic-images/hospital.svg', pattern: /hospital|clinic|doctor|nurse|surgery|patient/ },
  { image: '/topic-images/medicine.svg', pattern: /medicine|drug|pharmacy|vaccine|treatment/ },
  { image: '/topic-images/health.svg', pattern: /health|disease|medical|public health/ },
  { image: '/topic-images/housing.svg', pattern: /housing|home buyer|mortgage|rent|rental|homeless/ },
  { image: '/topic-images/construction.svg', pattern: /construction|building consent|infrastructure|developer/ },
  { image: '/topic-images/cost-of-living.svg', pattern: /cost of living|grocery|household bills|prices|affordability/ },
  { image: '/topic-images/banking.svg', pattern: /bank|interest rate|reserve bank|mortgage rate|cash rate/ },
  { image: '/topic-images/jobs.svg', pattern: /jobs|employment|unemployment|workforce|wages|workers/ },
  { image: '/topic-images/small-business.svg', pattern: /small business|retail|shop|cafe|restaurant|entrepreneur/ },
  { image: '/topic-images/shipping.svg', pattern: /shipping|vessel|port|freight|cargo|maritime/ },
  { image: '/topic-images/customs.svg', pattern: /customs|border force|biosecurity|passport|visa/ },
  { image: '/topic-images/trade.svg', pattern: /trade|export|import|tariff|container/ },
  { image: '/topic-images/economy.svg', pattern: /economy|inflation|gdp|fiscal|budget|financial|market/ },
  { image: '/topic-images/dairy.svg', pattern: /dairy|milk price|farming cooperative/ },
  { image: '/topic-images/farming.svg', pattern: /farm|farmer|agriculture|rural|livestock|crop/ },
  { image: '/topic-images/food.svg', pattern: /food|produce|supermarket|hunger|meal/ },
  { image: '/topic-images/university.svg', pattern: /university|tertiary|campus|graduate/ },
  { image: '/topic-images/school.svg', pattern: /school|teacher|classroom|student|education ministry/ },
  { image: '/topic-images/education.svg', pattern: /education|learning|qualification|training/ },
  { image: '/topic-images/charity.svg', pattern: /charity|volunteer|donation|food bank|nonprofit/ },
  { image: '/topic-images/multicultural.svg', pattern: /multicultural|ethnic|migrant community|language week|diversity/ },
  { image: '/topic-images/immigration.svg', pattern: /immigration|migrant|refugee|citizenship|residency|visa/ },
  { image: '/topic-images/community.svg', pattern: /community|neighbourhood|local group|family/ },
  { image: '/topic-images/flood.svg', pattern: /flood|flooding|inundation|rising water/ },
  { image: '/topic-images/storm.svg', pattern: /storm|cyclone|hurricane|tornado|severe weather|rain warning/ },
  { image: '/topic-images/bushfire.svg', pattern: /bushfire|wildfire|fire emergency/ },
  { image: '/topic-images/climate.svg', pattern: /climate|emissions|global warming|carbon/ },
  { image: '/topic-images/environment.svg', pattern: /environment|conservation|wildlife|pollution|forest/ },
  { image: '/topic-images/pacific.svg', pattern: /pacific|fiji|samoa|tonga|vanuatu|papua new guinea|solomon islands/ },
  { image: '/topic-images/new-zealand.svg', pattern: /new zealand|aotearoa|auckland|wellington|christchurch|waikato/ },
  { image: '/topic-images/australia.svg', pattern: /australia|australian|sydney|melbourne|perth|brisbane|adelaide|tasmania/ },
  { image: '/topic-images/defence.svg', pattern: /defence|defense|military|army|navy|air force|security/ },
  { image: '/topic-images/rugby.svg', pattern: /rugby|all blacks|wallabies|nrl|super rugby/ },
  { image: '/topic-images/cricket.svg', pattern: /cricket|test match|ashes|wicket/ },
  { image: '/topic-images/football.svg', pattern: /football|soccer|fifa|a-league/ },
  { image: '/topic-images/netball.svg', pattern: /netball|silver ferns/ },
  { image: '/topic-images/sport.svg', pattern: /sport|athlete|championship|olympic|commonwealth games/ },
]

const categoryDefaults: Record<CategorySlug, string> = {
  politics: '/topic-images/government.svg',
  'nz-pacific': '/topic-images/new-zealand.svg',
  australia: '/topic-images/australia.svg',
  business: '/topic-images/economy.svg',
  community: '/topic-images/community.svg',
  sports: '/topic-images/sport.svg',
  'editorial-view': '/topic-images/justice.svg',
}

export function getTopicImage(title: string, summary: string, category: CategorySlug): string {
  const text = `${title} ${summary}`.toLowerCase()
  return topicRules.find((rule) => rule.pattern.test(text))?.image ?? categoryDefaults[category]
}
