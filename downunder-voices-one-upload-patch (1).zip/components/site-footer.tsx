import Image from 'next/image'
import Link from 'next/link'
import { categories } from '@/lib/news-data'
import { SocialLinks } from '@/components/social-links'

const legal = [['Privacy','/privacy'],['Terms','/terms'],['Editorial Policy','/editorial-policy'],['Corrections','/corrections'],['Copyright','/copyright'],['Advertise','/advertise']]

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-border bg-foreground text-background">
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <div className="rounded bg-background p-3"><Image src="/downunder-voices-logo.svg" alt="Downunder Voices" width={760} height={150} className="h-auto w-full max-w-sm" /></div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-background/70">Independent news, community voices and fair-minded commentary for Australia, New Zealand and the Pacific.</p>
            <div className="mt-5"><SocialLinks /></div>
          </div>
          <div><h2 className="text-sm font-semibold uppercase tracking-wide text-background/60">Sections</h2><ul className="mt-4 grid grid-cols-2 gap-2 text-sm">{categories.map((category)=><li key={category.slug}><Link href={`/category/${category.slug}`} className="text-background/80 hover:text-background">{category.name}</Link></li>)}</ul></div>
          <div><h2 className="text-sm font-semibold uppercase tracking-wide text-background/60">Information</h2><ul className="mt-4 grid grid-cols-2 gap-2 text-sm"><li><Link href="/about">About</Link></li><li><Link href="/submit">Submit a story</Link></li><li><Link href="/contact">Contact</Link></li>{legal.map(([name,href])=><li key={href}><Link href={href} className="text-background/80 hover:text-background">{name}</Link></li>)}</ul></div>
        </div>
        <div className="mt-10 rounded-md border border-background/20 bg-background/5 p-4"><p className="text-xs leading-relaxed text-background/70"><strong className="text-background/90">Editorial note:</strong> Summaries and community commentary are not substitutes for original reporting. Follow the source link for the publisher&apos;s complete report.</p></div>
        <div className="mt-8 flex flex-col justify-between gap-3 border-t border-background/20 pt-6 text-xs text-background/60 sm:flex-row"><p>© {new Date().getFullYear()} Downunder Voices.</p><p>Every voice matters. Justice requires listening.</p></div>
      </div>
    </footer>
  )
}
