'use client'

import Image from 'next/image'
import { useMemo, useState } from 'react'
import { getTopicImage } from '@/lib/topic-images'
import type { CategorySlug } from '@/lib/news-data'

type StoryImageProps = {
  src?: string | null
  alt: string
  sizes: string
  className?: string
  category?: string | null
}

export function StoryImage({
  src,
  alt,
  sizes,
  className = '',
  category,
}: StoryImageProps) {
  const fallback = useMemo(() => {
    if (!category) return '/topic-images/world.svg'
    return getTopicImage(alt, '', category as CategorySlug)
  }, [category])

  const original = src?.trim() || ''

  const isPlaceholder =
    !original ||
    original.includes('placeholder.svg') ||
    original.includes('placeholder.jpg') ||
    original.includes('placeholder.png')

  const [source, setSource] = useState(
    isPlaceholder ? fallback : original,
  )

  return (
    <Image
      src={source}
      alt={alt}
      fill
      unoptimized
      className={className}
      sizes={sizes}
      onError={() => {
        if (source !== fallback) {
          setSource(fallback)
        }
      }}
    />
  )
}
