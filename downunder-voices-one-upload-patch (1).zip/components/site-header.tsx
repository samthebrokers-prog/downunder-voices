'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { categories } from '@/lib/news-data'
import { SocialLinks } from '@/components/social-links'

const navLinks = [
  ...categories.map((c) => ({ href: `/category/${c.slug}`, label: c.name })),
  { href: '/submit', label: 'Submit Your Story' },
  { href: '/about', label: 'About' },
  { href: '/contact', label: 'Contact' },
]

export function SiteHeader() {
  const [open, setOpen] = useState(false)
  const [today, setToday] = useState('')

  useEffect(() => {
    setToday(new Date().toLocaleDateString('en-NZ', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }))
  }, [])

  return (
    <header className="border-b border-border bg-background">
      <div className="border-b border-border bg-secondary">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-2 text-xs text-muted-foreground">
          <span className="hidden sm:inline" suppressHydrationWarning>{today}</span>
          <span className="font-medium uppercase tracking-wide">NZ · Australia · Pacific</span>
        </div>
      </div>

      <div className="mx-auto flex max-w-6xl items-center justify-between gap-5 px-4 py-4">
        <Link href="/" className="block shrink-0" aria-label="Downunder Voices home">
          <Image src="/downunder-voices-logo.svg" alt="Downunder Voices — Independent News, Community and Justice" width={760} height={150} priority className="h-auto w-[290px] sm:w-[390px]" />
        </Link>

        <div className="hidden items-end gap-5 lg:flex">
          <p className="max-w-lg text-right text-xs leading-relaxed text-muted-foreground">
            Independent news, community perspectives and public accountability across Australia, New Zealand and the Pacific.
          </p>
          <SocialLinks compact />
        </div>

        <button type="button" onClick={() => setOpen((value) => !value)} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium lg:hidden" aria-expanded={open} aria-label="Toggle navigation menu">
          {open ? <X className="size-4" /> : <Menu className="size-4" />} Menu
        </button>
      </div>

      <nav aria-label="Primary" className="hidden border-t border-border bg-foreground lg:block">
        <ul className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 px-4">
          {navLinks.map((link) => <li key={link.href}><Link href={link.href} className="inline-block py-3 text-sm font-medium text-background/80 transition-colors hover:text-background">{link.label}</Link></li>)}
        </ul>
      </nav>

      {open && (
        <nav aria-label="Mobile" className="border-t border-border bg-background lg:hidden">
          <div className="mx-auto max-w-6xl px-4 pt-3"><SocialLinks compact /></div>
          <ul className="mx-auto flex max-w-6xl flex-col px-4 py-2">
            {navLinks.map((link) => <li key={link.href}><Link href={link.href} onClick={() => setOpen(false)} className="block border-b border-border py-3 text-sm font-medium text-foreground last:border-b-0">{link.label}</Link></li>)}
          </ul>
        </nav>
      )}
    </header>
  )
}
