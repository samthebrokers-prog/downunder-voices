import type { SVGProps } from 'react'

type IconProps = SVGProps<SVGSVGElement>

const links = [
  { label: 'Facebook', href: process.env.NEXT_PUBLIC_FACEBOOK_URL || 'https://www.facebook.com/', Icon: FacebookIcon },
  { label: 'YouTube', href: process.env.NEXT_PUBLIC_YOUTUBE_URL || 'https://www.youtube.com/', Icon: YouTubeIcon },
  { label: 'Instagram', href: process.env.NEXT_PUBLIC_INSTAGRAM_URL || 'https://www.instagram.com/', Icon: InstagramIcon },
  { label: 'X', href: process.env.NEXT_PUBLIC_X_URL || 'https://x.com/', Icon: XIcon },
  { label: 'LinkedIn', href: process.env.NEXT_PUBLIC_LINKEDIN_URL || 'https://www.linkedin.com/', Icon: LinkedInIcon },
]

export function SocialLinks({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2" aria-label="Downunder Voices social media">
      {links.map(({ label, href, Icon }) => (
        <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
          className={`inline-flex items-center justify-center rounded-full border transition-colors ${compact ? 'size-8 border-border bg-background text-foreground hover:border-primary hover:text-primary' : 'size-9 border-background/25 text-background/80 hover:border-background hover:text-background'}`}>
          <Icon className="size-4" />
        </a>
      ))}
    </div>
  )
}

function FacebookIcon(props: IconProps) { return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}><path d="M14 8.5V7c0-.8.5-1 1-1h2V2.2A25 25 0 0 0 14.1 2C11.2 2 9 3.8 9 7.2v1.3H6V12h3v10h4V12h3.2l.5-3.5H14Z"/></svg> }
function YouTubeIcon(props: IconProps) { return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}><path d="M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2 31 31 0 0 0 .5 12c0 1.6.1 3.3.5 4.8a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1c.4-1.5.5-3.2.5-4.8s-.1-3.3-.5-4.8ZM9.7 15.2V8.8l5.6 3.2-5.6 3.2Z"/></svg> }
function InstagramIcon(props: IconProps) { return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true" {...props}><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg> }
function XIcon(props: IconProps) { return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}><path d="M18.9 2H22l-6.8 7.8L23.2 22h-6.3l-4.9-6.4L6.4 22H3.3l7.2-8.3L2.8 2h6.4l4.4 5.8L18.9 2Zm-1.1 17.9h1.7L8.3 4H6.5l11.3 15.9Z"/></svg> }
function LinkedInIcon(props: IconProps) { return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}><path d="M5.3 7.8A2.3 2.3 0 1 0 5.3 3a2.3 2.3 0 0 0 0 4.7ZM3.3 21h4V9h-4v12Zm6.5 0h4v-6.7c0-1.8.3-3.5 2.6-3.5 2.3 0 2.3 2.1 2.3 3.6V21h4v-7.4c0-3.6-.8-6.4-5-6.4-2 0-3.4 1.1-4 2.2h-.1V9H9.8v12Z"/></svg> }
